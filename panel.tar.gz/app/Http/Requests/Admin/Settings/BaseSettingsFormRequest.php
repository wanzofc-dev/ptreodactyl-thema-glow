<?php

namespace Pterodactyl\Http\Requests\Admin\Settings;

use Illuminate\Validation\Rule;
use Pterodactyl\Traits\Helpers\AvailableLanguages;
use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class BaseSettingsFormRequest extends AdminFormRequest
{
    use AvailableLanguages;

    public function rules(): array
    {
        return [
            'app:name' => 'required|string|max:191',
            'pterodactyl:auth:2fa_required' => 'required|integer|in:0,1,2',
            'app:locale' => ['required', 'string', Rule::in(array_keys($this->getAvailableLanguages()))],
            'nook:theme:logo' => 'nullable|string',
            'nook:theme:background' => 'nullable|string',
            'nook:theme:icon' => 'nullable|string',
            'nook:theme:login_logo' => 'nullable|string',
        ];
    }

    public function attributes(): array
    {
        return [
            'app:name' => 'Company Name',
            'pterodactyl:auth:2fa_required' => 'Require 2-Factor Authentication',
            'app:locale' => 'Default Language',
            'nook:theme:logo' => 'Dashboard Logo URL',
            'nook:theme:background' => 'Background Image URL',
            'nook:theme:icon' => 'Favicon URL',
            'nook:theme:login_logo' => 'Login Logo URL',
        ];
    }
}
