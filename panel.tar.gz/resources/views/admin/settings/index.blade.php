@extends('layouts.admin')
@include('partials/admin.settings.nav', ['activeTab' => 'basic'])

@section('title')
    Settings
@endsection

@section('content-header')
    <h1>Panel Settings<small>Configure Pterodactyl to your liking.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Panel Settings</h3>
                </div>
                <form action="{{ route('admin.settings') }}" method="POST">
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label class="control-label">Company Name</label>
                                <div>
                                    <input type="text" class="form-control" name="app:name" value="{{ old('app:name', config('app.name')) }}" />
                                    <p class="text-muted"><small>This is the name that is used throughout the panel and in emails sent to clients.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="control-label">Require 2-Factor Authentication</label>
                                <div>
                                    <div class="btn-group" data-toggle="buttons">
                                        @php
                                            $level = old('pterodactyl:auth:2fa_required', config('pterodactyl.auth.2fa_required'));
                                        @endphp
                                        <label class="btn btn-primary @if ($level == 0) active @endif">
                                            <input type="radio" name="pterodactyl:auth:2fa_required" autocomplete="off" value="0" @if ($level == 0) checked @endif> Not Required
                                        </label>
                                        <label class="btn btn-primary @if ($level == 1) active @endif">
                                            <input type="radio" name="pterodactyl:auth:2fa_required" autocomplete="off" value="1" @if ($level == 1) checked @endif> Admin Only
                                        </label>
                                        <label class="btn btn-primary @if ($level == 2) active @endif">
                                            <input type="radio" name="pterodactyl:auth:2fa_required" autocomplete="off" value="2" @if ($level == 2) checked @endif> All Users
                                        </label>
                                    </div>
                                    <p class="text-muted"><small>If enabled, any account falling into the selected grouping will be required to have 2-Factor authentication enabled to use the Panel.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="control-label">Default Language</label>
                                <div>
                                    <select name="app:locale" class="form-control">
                                        @foreach($languages as $key => $value)
                                            <option value="{{ $key }}" @if(config('app.locale') === $key) selected @endif>{{ $value }}</option>
                                        @endforeach
                                    </select>
                                    <p class="text-muted"><small>The default language to use when rendering UI components.</small></p>
                                </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <h4 style="margin-top:20px; border-bottom: 1px solid #ddd; padding-bottom: 10px;">NookTheme Glassmorphism Settings</h4>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label">Background Image URL</label>
                                <div>
                                    <input type="text" class="form-control" name="nook:theme:background" id="nookBg" value="{{ old('nook:theme:background', config('nook.theme.background')) }}" placeholder="https://..." />
                                    <p class="text-muted"><small>URL for the panel's background image. Leave empty to use the default dark color.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label">Dashboard Logo URL</label>
                                <div>
                                    <input type="text" class="form-control" name="nook:theme:logo" id="nookLogo" value="{{ old('nook:theme:logo', config('nook.theme.logo')) }}" placeholder="https://..." />
                                    <p class="text-muted"><small>URL for the top-left logo. Leave empty to use default text.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label">Login Logo URL</label>
                                <div>
                                    <input type="text" class="form-control" name="nook:theme:login_logo" id="nookLogin" value="{{ old('nook:theme:login_logo', config('nook.theme.login_logo')) }}" placeholder="https://..." />
                                    <p class="text-muted"><small>URL for the large logo on the login page.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label">Favicon Icon URL</label>
                                <div>
                                    <input type="text" class="form-control" name="nook:theme:icon" id="nookIcon" value="{{ old('nook:theme:icon', config('nook.theme.icon')) }}" placeholder="https://..." />
                                    <p class="text-muted"><small>URL for the browser tab icon (.png or .ico).</small></p>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <button type="button" class="btn btn-sm btn-default" onclick="document.getElementById('nookBg').value = ''; document.getElementById('nookLogo').value = ''; document.getElementById('nookLogin').value = ''; document.getElementById('nookIcon').value = '';">Reset to Default (Clear All)</button>
                                <p class="text-muted"><small>Clicking reset will empty the fields. You still need to click <strong>Save</strong> at the bottom to apply the defaults.</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" name="_method" value="PATCH" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
