<!DOCTYPE html>
<html>
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">
            <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
            <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
            <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
            <link rel="manifest" href="/favicons/manifest.json">
            <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
            <link rel="shortcut icon" href="/favicons/favicon.ico">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
            <meta name="theme-color" content="#0e4688">
        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show

        @yield('assets')

        @include('layouts.scripts')
        <link rel="stylesheet" href="/glassmorphism.css">
        
        @php
            $settings = app(\Pterodactyl\Contracts\Repository\SettingsRepositoryInterface::class);
            $bg = $settings->get('settings::nook:theme:background', '');
            $logo = $settings->get('settings::nook:theme:logo', '');
            $login_logo = $settings->get('settings::nook:theme:login_logo', '');
            $icon = $settings->get('settings::nook:theme:icon', '');
        @endphp
        
        @if(!empty($icon))
            <link rel="shortcut icon" href="{{ $icon }}">
            <link rel="icon" type="image/png" href="{{ $icon }}">
        @endif
        
        <style>
            @if(!empty($bg) && !str_ends_with(strtolower($bg), '.mp4'))
                body, html, #app {
                    background-image: url('{{ $bg }}') !important;
                    background-size: cover !important;
                    background-attachment: fixed !important;
                    background-position: center !important;
                }
            @endif
            @if(!empty($logo))
                /* Target Dashboard Logo */
                div[class*="NavigationBar"] > a > img,
                div[class*="NavigationBar"] > a,
                .logo {
                    content: url('{{ $logo }}') !important;
                    object-fit: contain;
                }
            @endif
            @if(!empty($login_logo))
                /* Target Login Logo via src attribute */
                img[src*="pterodactyl.svg"] {
                    content: url('{{ $login_logo }}') !important;
                    object-fit: contain;
                }
            @endif
        </style>
    </head>
    <body class="bg-black">
        @if(!empty($bg) && str_ends_with(strtolower($bg), '.mp4'))
            <style>
                body, html, #app, .App__container {
                    background: transparent !important;
                    background-color: transparent !important;
                }
            </style>
            <video autoplay loop id="nook-bg-video" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: -9999; object-fit: cover; pointer-events: none;">
                <source src="{{ $bg }}" type="video/mp4">
            </video>
            <script>
                // Modern browsers block autoplay with sound unless user interacted.
                // We attempt to play it with sound, but fallback to muted if blocked.
                document.addEventListener('DOMContentLoaded', function() {
                    var vid = document.getElementById('nook-bg-video');
                    if(vid) {
                        vid.muted = false;
                        var playPromise = vid.play();
                        if (playPromise !== undefined) {
                            playPromise.catch(function(error) {
                                vid.muted = true;
                                vid.play();
                                console.log("Browser blocked autoplay with sound. Fallback to muted.");
                            });
                        }
                    }
                });
            </script>
        @endif
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
